# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

{
    'name': "Uppercrust Blog",
    'description': """
    Customized Uppercrust Theme: Blog snippet.""",
    'version': "1.0",
    'author': "Synconics Technologies Pvt. Ltd.",
    'website': "www.synconics.com",
    'catagory': '',
    'depends': ['website_blog','sync_uppercrust_theme'],
    'data': [
        'views/assets_registry.xml',
        'views/blog_templates.xml',
    ],
    'active': True,
    'installable': True,
}
