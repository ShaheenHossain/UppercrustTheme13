# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from odoo import models, _


class ResPartner(models.Model):
    _inherit = "res.partner"

    def google_map_address(self, zoom=8):
        partner = self.browse(self._ids)
        params = {
            'q': '%s, %s %s, %s' % (partner.street or '', partner.city or '', partner.zip or '', partner.country_id and partner.country_id.name_get()[0][1] or ''),
        }        
        return params['q'].replace(',', ' ')


class ResCompany(models.Model):
    _inherit = "res.company"

    def google_map_address(self,zoom=8):
        partner = self.browse(self._ids[0]).partner_id
        return partner and partner.google_map_address(zoom) or None
