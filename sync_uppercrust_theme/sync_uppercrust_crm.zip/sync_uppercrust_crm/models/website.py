# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models


class Website(models.Model):

    _inherit = "website"

    contact_image = fields.Binary(string="Website Contact Image")