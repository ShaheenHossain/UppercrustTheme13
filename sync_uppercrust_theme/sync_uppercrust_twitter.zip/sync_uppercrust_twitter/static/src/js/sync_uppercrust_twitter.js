odoo.define('sync_uppercrust_twitter.animation', function (require) {
'use strict';

var core = require('web.core');
var publicWidget = require('web.public.widget');

var qweb = core.qweb;
var _t = core._t;
    publicWidget.registry.twitter.include({
    xmlDependencies: ['/sync_uppercrust_twitter/static/src/xml/templates.xml'],
    start: function () {
        var self = this;
        var $timeline = this.$('.twitter_timeline');
        $timeline.append('<center><div><img src="/website_twitter/static/src/img/loadtweet.gif"></div></center>');
        var def = this._rpc({route: '/website_twitter/get_favorites'}).then(function (data) {
            $timeline.empty();
            if (data.error) {
                $timeline.append(qweb.render('website.Twitter.Error', {data: data}));
                return;
            }

            if (_.isEmpty(data)) {
                return;
            }

            var tweets = _.map(data, function (tweet, index) {
                // Parse tweet date
                if (_.isEmpty(tweet.created_at)) {
                    tweet.created_at = '';
                } else {
                    var v = tweet.created_at.split(' ');
                    var d = new Date(Date.parse(v[1]+' '+v[2]+', '+v[5]+' '+v[3]+' UTC'));
                    tweet.created_at = d.toDateString();
                }
                tweet.user.profile_image_url = tweet.user.profile_image_url.replace('_normal', '');
                // Parse tweet text
                tweet.sequence = index;
                tweet.text = tweet.text
                    .replace(
                        /[A-Za-z]+:\/\/[A-Za-z0-9-_]+\.[A-Za-z0-9-_:%&~\?\/.=]+/g,
                        function (url) {
                            return _makeLink(url, url);
                        }
                    )
                    .replace(
                        /[@]+[A-Za-z0-9_]+/g,
                        function (screen_name) {
                            return _makeLink('http://twitter.com/' + screen_name.replace('@', ''), screen_name);
                        }
                    )
                    .replace(
                        /[#]+[A-Za-z0-9_]+/g,
                        function (hashtag) {
                            return _makeLink('http://twitter.com/search?q='+hashtag.replace('#',''), hashtag);
                        }
                    );
                return tweet;
                // return qweb.render('website.Twitter.Scroller.Custom', {tweet: tweet})).appendTo($timeline);

                function _makeLink(url, text) {
                    var c = $('<a/>', {
                        text: text,
                        href: url,
                        target: '_blank',
                    });
                    return c.prop('outerHTML');
                }
            });

            var f = Math.floor(tweets.length / 3);
            var tweetSlices = [tweets.slice(0, f).join(' '), tweets.slice(f, f * 2).join(' '), tweets.slice(f * 2, tweets.length).join(' ')];
            $(qweb.render('website.Twitter.Scroller.Custom', {tweets: tweets})).appendTo($timeline);
        });
        return def;
    },
});
});
